/*	SO - 1 Entrega 
	
	Grupo: 25
	Tiago Henriques- 81633
	Pedro Cunha- 82343
	Tomas Zaky- 79690 */ 

/* Bibliotecas */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>						
#include <unistd.h>		
#include <sys/types.h>	
#include <sys/wait.h>   
#include <signal.h>
#include <pthread.h>
#include <time.h>

/* outros ficheiros*/
#include "commandlinereader.h"
#include "list.h" 

/* Constantes*/
#define TRUE 1
#define MAXARG 7 /* Comand + 5 arg + NULL */


void prompt(); /* imprime uma frase de boas vindas na shell*/
void *tarefa_monitora();

/* variaveis globais */
int gf_exit = 0;
int g_numChildren = 0;
pthread_mutex_t g_lock;
list_t *g_list;


int main() {
	int pid, numTokens;	
	char *lstProcess[MAXARG]; /* Lista com todos os processos */
	pthread_t tarefa;

	prompt();
	pthread_mutex_init(&g_lock, NULL);
	g_list = lst_new(); /* inicia a lista */

	if(pthread_create(&tarefa, NULL, &tarefa_monitora, NULL) != 0){
		printf("Erro\n");
		exit(EXIT_FAILURE);
	}
	while (TRUE){
		numTokens = readLineArguments(lstProcess, MAXARG);
		
		if(numTokens < 0){
			printf("Erro: acao impossivel\n");
			continue;
		}
		else if(numTokens == 0){
			continue;
		}
		else{
			if (strcmp(lstProcess[0], "exit") == 0){
				gf_exit = 1;
				break;
			}
			
			pid = fork();
			if (pid == -1) 
				perror("Erro: fork impossivel de executar\n");
			else if (pid == 0){ /* processo filho */
				execv(lstProcess[0], lstProcess);
				printf("Erro: ocorreu um erro durante o execv\n");
				exit(EXIT_FAILURE);
			}
			else{ /* processo pai */
				pthread_mutex_lock(&g_lock);
				g_numChildren++;
				insert_new_process(g_list, pid , time(NULL));
				pthread_mutex_unlock(&g_lock);
				continue;
			}
		}
	}

	pthread_join(tarefa, NULL);
	lst_print(g_list);
	lst_destroy(g_list);
	pthread_mutex_destroy(&g_lock);
	return 0;
}


/* Introduz uma frase de boas vindas no terminal */
void prompt(){ 
	printf("Introduza uma instrucao\n");
}

void *tarefa_monitora(){
	int pid, estado;

	while(TRUE){
		if (gf_exit == 1 && g_numChildren == 0)
			break;
		
		if (g_numChildren < 0){
			printf("Erro: numero de processos filho invalido");
			exit(EXIT_FAILURE);
		}
		else if(g_numChildren == 0)
			sleep(1);
		else{
			pid = wait(&estado);
			pthread_mutex_lock(&g_lock);
			update_terminated_process(g_list, pid, time(NULL));
			g_numChildren--;
			pthread_mutex_unlock(&g_lock);
		}
	}
	return NULL;
}